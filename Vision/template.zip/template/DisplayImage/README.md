# DisplayImage
Example application to load and display an image.

To build:

    mkdir build
    cd build
    cmake ..
    make

To run:

    cd build
    ./DisplayImage ../book.jpg
