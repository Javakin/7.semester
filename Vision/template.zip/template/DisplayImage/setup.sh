#!/bin/bash
####################################
#
# This schript will auto assemble
# a DisplayImage project
#
####################################
mkdir build
cd build
cmake ..
make

